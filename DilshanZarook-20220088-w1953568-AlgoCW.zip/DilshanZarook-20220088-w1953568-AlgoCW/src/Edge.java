class Edge {
    Node start;
    Node end;
    int cost;

    public Edge(Node start, Node end, int cost) {
        this.start = start;
        this.end = end;
        this.cost = cost;
    }
}